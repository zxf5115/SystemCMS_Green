$(document).ready(function(){

  $(".pb").click(function(){
    $(this).parent().parent().hide();
  })

})


